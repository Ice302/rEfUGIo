Tiny Planes - Boeing 747-8I - livery template (UV map), layout 1: side views, ONE sheet
=========================================================================================

The whole plane is painted with ONE square texture. Paint it at 4096 x 4096 (recommended, about 1.9 cm per pixel)
or 2048 x 2048 (about 3.8 cm per pixel). The layout is the same either way.

What is where (the labels are on the guide):
  LEFT SIDE      the fuselage seen from the left, nose at the left.
  RIGHT SIDE     the fuselage seen from the right, nose at the right.
                   These are side views: what you paint is what you see standing next to the plane. A straight
                   stripe on the sheet is straight on the plane. The crown runs along the top edge and the belly along
                   the bottom edge, drawn a little squeezed. Windows, doors and the cockpit glass are drawn dark.
  WING, TOP      seen from above, nose up: the LEFT wing is on the left.
  WING, UNDERSIDE  seen from below, nose up: the LEFT wing is on the RIGHT.
  TAILPLANE, TOP / UNDERSIDE   the same way.
  FIN, LEFT SIDE / RIGHT SIDE   each seen from its own side.
  BELLY FAIRING, LEFT / RIGHT SIDE   the wing-to-body fairing under the wings, each seen from its own side.
  ENGINE 1 (LEFT OUTER), ENGINE 2 (LEFT INNER), ENGINE 3 (RIGHT INNER), ENGINE 4 (RIGHT OUTER)   each cowl unrolled:
                   the top along the top edge, then the outboard side, the bottom and the inboard side; front towards
                   the nose side of the sheet. The zig-zag (chevron) nozzle at the back of each engine shares its last
                   few pixels between neighbouring teeth, so keep that back edge one colour.
  The 747-8I has raked wing tips and no winglets: the tips are part of WING, TOP and WING, UNDERSIDE.
  Swatches, one colour each: FLAP FAIRINGS (the canoes under the wings) and PYLONS (the four engine pylons).
  The gear doors are painted where they sit when closed (gear up), so they carry the paint of the belly and the
                   belly fairing round them.

Every piece is drawn the way you see it from its own side, so words and numbers read the right way round on BOTH
sides. Paint the two sides separately: never mirror one side onto the other.

Files
  B748I_livery_base_4096.png    the current paint at 4096 x 4096. Start from this.
  B748I_livery_base.png         the same at 2048 x 2048.
  B748I_livery_guide_4096.png   transparent overlay: outlines, mesh lines, windows and doors, hidden areas, metre ticks
                              and labels. Keep it on top while you paint, hide it to export.
  B748I_livery_guide.png        the same at 2048 x 2048.
  B748I_overview.png            the template at a glance.
  B748I_orientation_check.png   a test texture on the model: the text reads correctly on both sides.

Tips
  - One metre on the plane is about 52 pixels at 4096 (26 at 2048).
  - The ticks along the belly of each side are metres from the nose (numbered every 5 m).
  - The thin grey mesh lines follow the shape of the plane, like the wireframe on classic livery templates.
  - Hatched areas are hidden on the model. Paint over them freely.
  - Carry your colours a few pixels past each outline so the seams don't show.
  - Lines thinner than 2 pixels blur away. Big bold shapes and lettering read best.
  - Export a square PNG: 4096 x 4096 (or 2048 x 2048).
